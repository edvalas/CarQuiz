﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace project
{
    public partial class Page8 : PhoneApplicationPage
    {
        public Page8()
        {
            InitializeComponent();
        }

        private void img1_Tap(object sender, GestureEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Page9.xaml", UriKind.RelativeOrAbsolute));
        }

        private void img2_Tap(object sender, GestureEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Page9.xaml", UriKind.RelativeOrAbsolute));
        }

        private void img3_Tap(object sender, GestureEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Page9.xaml", UriKind.RelativeOrAbsolute));
        }

        private void img4_Tap(object sender, GestureEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Page9.xaml", UriKind.RelativeOrAbsolute));
            Globals.counter++;
        }
    }
}